"""AUTOCRYPT V4 — Project Configuration

Provides deterministic configuration boundaries for the project.
All config is source-first; no implicit or dynamic loading.
"""

# Project identity
PROJECT_NAME = "AUTOCRYPT_V4"
PROJECT_VERSION = "1.0.0"
PROJECT_DOCTRINE = "CORRECTNESS > REPRODUCIBILITY > SAFETY > ROBUSTNESS > PERFORMANCE > SPEED"
TRADING_AUTHORITY = "RISK > STRATEGY > MODEL/LLM"

# Hard project goals (cannot be silently relaxed)
HARD_GOALS = {
    "OOS_Sharpe": ">= 1.50",
    "average_trades_per_day": ">= 4.00",
    "max_drawdown": "<= 20.00%",
}

# Optimization objective: minimize Max DD among candidates satisfying hard gates
OPTIMIZATION_OBJECTIVE = "MINIMIZE_MAX_DD"

# Secondary preferences (ordered)
SECONDARY_PREFERENCES = [
    "higher OOS Sharpe",
    "higher Sortino",
    "better expectancy",
    "better cost robustness",
    "better WFO stability",
    "better coin robustness",
    "better regime robustness",
]

# 6-coin universe (per roadmap Phases 14-21)
COIN_UNIVERSE = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT", "ADAUSDT"]

# Primary timeframe
PRIMARY_TIMEFRAME = "15m"

# Data lifecycle stages (per roadmap Phases 14-15)
DATA_LIFECYCLE = ["RAW", "CLEAN", "VALIDATE", "FEATURES", "LABELS", "DATASET"]

# Data layer metadata (every layer gets)
DATA_METADATA = ["version", "hash", "date_range", "symbols", "row_count", "source"]

# Git branch conventions (per roadmap Phase 3)
GIT_BRANCH_CONVENTIONS = {
    "protected": "main",
    "agent": "agent/<name>",
    "research": "research/<descr>",
    "audit": "audit/<descr>",
    "model": "model/<tag>",
    "dataset": "dataset/<tag>",
}

# GIT workflow (per roadmap Phase 3)
GIT_WORKFLOW = {
    "change": "branch → change → test → commit → review → merge",
    "version_models": "KRN-V0, KRN-V1, ...",
    "version_experiments": "RUN-0001, RUN-0002, ...",
}

# Colab configuration (per roadmap Phase 31)
COLAB = {
    "heavy_tasks": [
        "training",
        "fine-tuning",
        "large_backtests",
        "WFO",
        "bootstrap",
        "Monte_Carlo",
        "hyperparameter_sweeps",
        "large_dataset_generation",
        "model_export",
    ],
    "package": ["README.md", "notebook.ipynb", "requirements.txt", "config", "expected_outputs", "checksums"],
    "human_workflow": "upload/run → return_results → agents_continue_autonomously_after_ingestion",
}

# Resource authorization (per roadmap Phase 30-34)
RESOURCE_AUTHORIZATION = {
    "plugins": "all legitimately available plugins",
    "skills": "all legitimately available skills",
    "connected_tools": "all connected tools",
    "git_tools": "Git tools",
    "file_tools": "file tools",
    "web_research_tools": "web/research tools",
    "ai_models": "AI models",
    "model_apis": "model APIs",
    "google_colab": "Google Colab",
    "gpu": "GPU",
    "cpu": "CPU",
    "storage": "storage",
    "scripts": "scripts",
    "notebooks": "notebooks",
    "datasets": "datasets",
    "models_artifacts": "models and artifacts",
    "selection_criteria": "correctness, quality_of_evidence, reliability, resource_efficiency",
    "does_not_override": "platform_rules, tool_permissions, credential_security, human_only_real_money_approval",
}

# Agent team definition (per bootstrap)
AGENT_TEAM = {
    "engineering_architect": {
        "role": "Python, architecture, debugging, testing, systems, Git, deployment, performance, Colab integration",
        "disciplines": [
            "Python",
            "Computer Science",
            "Data Structures & Algorithms",
            "Git and GitHub",
            "API Design",
            "Backend",
            "Software Architect",
            "Software Design and Architecture",
            "System Design",
            "Linux",
            "Bash/Shell",
            "Docker",
            "DevOps",
            "DevSecOps",
            "QA",
            "performance",
        ],
    },
    "quant_ml_researcher": {
        "role": "ML, time series, Kronos, forecasting, features, labels, alpha research, WFO, OOS, bootstrap, Monte Carlo, self-training, model evaluation",
        "disciplines": [
            "Machine Learning",
            "MLOps",
            "AI Engineer",
            "Python for Data Analysis",
            "Computer Science",
            "AI Agents",
            "Prompt Engineering",
            "AI Red Teaming",
        ],
    },
    "red_team_risk_auditor": {
        "role": "leakage, overfitting, backtest audit, risk, security, execution realism, adversarial testing, failure analysis",
        "disciplines": ["Cyber Security", "DevSecOps", "AI Red Teaming", "Cyber Security"],
    },
}

# Golden rule (per roadmap Phase 50)
GOLDEN_RULE = "Learn only what improves the project. Build only what the project can verify. Promote only what survives independent evaluation."

# Source basis (Per roadmap Phase 51)
SOURCE_BASIS = "nilbuild/developer-roadmap repository as external taxonomy, mapped into AUTOCRYPT project architecture, evolved-Kronos/self-training plan, multi-agent design, and source-first operating protocol."