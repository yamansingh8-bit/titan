"""AUTOCRYPT V4 — 5-Brain Architecture

Per roadmap Phases 8-9 and HANDOFF.md: MarketBrain → ReasoningBrain → RiskBrain → ExecutionBrain → LearningBrain.
External control plane: AI Agent Team (Engineering Architect, Quant/ML Researcher, Red Team/Risk Auditor) via AgentControlPlane.

Brain boundaries (per roadmap Phase 8):
- MarketBrain (L1-L10): Features, regimes, cointegration, OBI, meta-labeling
- ReasoningBrain: Kronos gate, Kimi K3, signal evaluation
- RiskBrain (L13): 5-gate pipeline (1.5% hard SL, liquidity, leverage, Kronos confidence, 5% DD circuit breaker)
- ExecutionBrain (L11-L12): TWAP/VWAP slicing, partial fill reconciliation, Binance Private WS
- LearningBrain (L14): Trade journal, post-trade attribution, self-improving harness
"""

# 5-Brain architecture (per HANDOFF.md & roadmap Phase 8)
BRAINS = {
    "MarketBrain": {
        "levels": "L1-L10",
        "responsibilities": {
            "L1-L10": "Classical technical indicators (RSI, BB, ATR, Donchian), market regime labels (regime_bull, regime_high_vol), StatArb cointegration vectors (SOL/ETH, BTC/ETH), orderbook imbalance (OBI), meta-labeling barrier probabilities",
            "output": "signal candidate",
        },
    },
    "ReasoningBrain": {
        "responsibilities": {
            "eval": "Kronos dual veto gatekeeper + local Kimi K3 GGUF under resource bounds (-c 256 -b 256 --threads 2, 4GB RAM dual-core)",
            "gate": "Kronos confidence >= 0.65; REJECT if confidence < 0.65, timeout > 3s, or crash (OOM); default REJECT",
        },
    },
    "RiskBrain": {
        "level": "L13",
        "responsibilities": {
            "5_gate_pipeline": "Hard SL <= 1.5% (SL > 1.5% = auto REJECT); Liquidity Depth; Leverage Cap; Kronos Confidence >= 0.65; Portfolio Drawdown < 5.0%",
            "circuit_breaker": "5% portfolio max drawdown -> HALT_ALL (all active orders cancelled, positions closed)",
        },
    },
    "ExecutionBrain": {
        "levels": "L11-L12",
        "responsibilities": {
            "order_router": "TWAP slicing, partial-fill reconciliation, Binance Private WS (wss://fstream.binance.com/private)",
            "output": "fill receipts",
        },
    },
    "LearningBrain": {
        "level": "L14",
        "responsibilities": {
            "trade_journal": "SQLite (db/trade_journal.sql) — trade performance log, post-trade attribution, parameter refinement",
            "self_improving": "self-improving-harness — refines strategy parameters",
        },
    },
}

# Brain control plane (per roadmap Phase 8)
AGENT_CONTROL_PLANE = {
    "definition": "AI Agent Team (Engineering Architect, Quant/ML Researcher, Red Team/Risk Auditor) — NOT a hidden trading brain",
    "relationship": "AgentControlPlane -> AUTOCRYPT development/research -> AUTOCRYPT trading system",
    "constraint": "agent layer cannot override RiskBrain",
}

# Brain versioning (per roadmap Phase 3)
BRAIN_VERSIONING = {
    "model_versions": "KRN-V0, KRN-V1, KRN-V2, ...",
    "experiment_versions": "RUN-0001, RUN-0002, ...",
}

# Exit gates per brain (per roadmap)
BRAIN_EXIT_GATES = {
    "MarketBrain": "[ ] all L1-L10 features implemented, causality checks passed, versioned feature manifests",
    "ReasoningBrain": "[ ] Kronos gate configured, Kimi K3 resource bounds verified, signal evaluation pipeline tested",
    "RiskBrain": "[ ] 5-gate pipeline active, 1.5% hard SL enforced, 5% DD circuit breaker tested, HALT_ALL trigger verified",
    "ExecutionBrain": "[ ] TWAP slicing tested, partial-fill reconciliation verified, Private WS connectivity confirmed",
    "LearningBrain": "[ ] SQLite schema created, trade journal logging tested, self-improving-harness integration verified",
}

# Key metrics per brain
BRAIN_METRICS = {
    "MarketBrain": ["feature_count", "causality_pass_rate", "version_hash"],
    "ReasoningBrain": ["kronos_approval_rate", "kronos_rejection_rate", "kronos_directional_quality"],
    "RiskBrain": ["hard_sL_compliance_rate", "circuit_breaker_trigger_rate", "max_drawdown"],
    "ExecutionBrain": ["order_fill_rate", "partial_fill_reconciliation_rate", "websocket_uptime"],
    "LearningBrain": ["trade_journal_entries", "self_improvement_iterations", "parameter_refinement_quality"],
}

# Key audit areas per brain (per red team auditor)
BRAIN_AUDIT_AREAS = {
    "MarketBrain": ["future_leakage", "state_leakage", "synthetic_fallback", "parameter_corruption"],
    "ReasoningBrain": ["prompt_injection", "model_abuse", "resource_exhaustion", "gate_bypass"],
    "RiskBrain": ["risk_policy_rewrite", "circuit_breaker_bypass", "authority_violation"],
    "ExecutionBrain": ["order_injection", "websocket_spoof", "fill_manipulation", "reconciliation_failures"],
    "LearningBrain": ["journal_tampering", "parameter_poisoning", "harness_bypass"],
}

# Golden rule per brain
BRAIN_GOLDEN_RULE = {
    "MarketBrain": "data first, features causal, versioned, reproducible",
    "ReasoningBrain": "Kronos gate preserves capital; no silent relaxations",
    "RiskBrain": "RiskAuthority > Strategy > Model; hard SL inviolable",
    "ExecutionBrain": "no model output -> real order without RiskBrain approval",
    "LearningBrain": "every failure -> root cause, fix, regression test, lesson",
}