"""AUTOCRYPT V4 — Data Engineering

Provides the data pipeline boundaries per roadmap Phases 7-14.
Real Binance data only; no synthetic fallback.
"""

# Trading universe (6 coins, per roadmap Phases 14-21)
COIN_UNIVERSE = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT", "ADAUSDT"]

# Primary timeframe (per roadmap Phases 14-15)
PRIMARY_TIMEFRAME = "15m"

# Data lifecycle stages (per roadmap Phases 14-15)
DATA_LIFECYCLE = ["RAW", "CLEAN", "VALIDATE", "FEATURES", "LABELS", "DATASET"]

# Every layer gets metadata: version, hash, date range, symbols, row count, source
DATA_METADATA_FIELDS = ["version", "hash", "date_range", "symbols", "row_count", "source"]

# Raw data sources (per roadmap)
RAW_DATA_SOURCES = {
    "binance_public_ws": "wss://fstream.binance.com/public",
    "binance_market_ws": "wss://fstream.binance.com/market",
    "binance_private_ws": "wss://fstream.binance.com/private",
}

# Lifecycle per layer
DATA_STAGE_DESCRIPTIONS = {
    "RAW": "Raw Binance OHLCV data; volume; funding; open interest where available; liquidations where available; microstructure where available",
    "CLEAN": "Cleaned data: deduplication, timestamp alignment, filter out-of-hours, basic sanity checks",
    "VALIDATE": "Validated data: checksum manifests, causality checks, no silent synthetic fallback, version/hash per stage",
    "FEATURES": "Engineered features: EMA/RSI/ATR/Bollinger/Donchian/ADX (L1); regime (L2); cointegration/spreads/z-score (L3); crypto carry/funding/basis (L4); stat-arb cross-sectional momentum/mean reversion (L5); OFI/CVD/book imbalance (L6); liquidation intensity/OI shock (L7); realized volatility/compression/expansion (L8)",
    "LABELS": "Structured labels: direction, TAKE/REJECT, future return, MFE, MAE, TP hit, SL hit, time to exit; triple-barrier labeling preferred; avoid final reliance on profit > 0 = YES",
    "DATASET": "Final dataset: versioned, hashed, with date range, symbols, row count, source; every row traceable to generation stage",
}

# Label engineering (per roadmap Phase 15)
LABEL_ENGINEERING = {
    "avoid": "final_relaince_on_profit_0_is_yes",
    "structured_targets": ["direction", "TAKE/REJECT", "future_return", "MFE", "MAE", "TP_hit", "SL_hit", "time_to_exit"],
    "preferred_design": "triple_barrier_labeling",
}

# Feature families (per roadmap Phase 15)
FEATURE_FAMILIES = {
    "L1_classical": ["EMA", "RSI", "ATR", "Bollinger", "Donchian", "ADX"],
    "L2_regime": ["regime"],
    "L3_relative_value": ["cointegration", "spreads", "z_score"],
    "L4_crypto_carry": ["funding", "basis", "carry"],
    "L5_stat_arb": ["cross-sectional_momentum", "mean_reversion"],
    "L6_microstructure": ["OFI", "CVD", "book_imbalance"],
    "L7_liquidation": ["liquidation_intensity", "OI_shock"],
    "L8_volatility": ["realized_volatility", "compression", "expansion"],
    "L9_ml_fusion": ["ML_fusion"],
    "L10_meta_labeling": ["meta_labeling"],
    "L11_portfolio": ["portfolio"],
    "L12_execution": ["execution"],
    "L13_risk": ["risk"],
    "L14_learning": ["learning"],
    "L15_optional_reasoning": ["optional_reasoning"],
}

# Causal rule (per roadmap Phase 16)
CAUSAL_RULE = "input at T <= information available before T"

# Execution causality (per roadmap Phase 16)
EXECUTION_CAUSALITY = "signal → order → entry → future price path"

# Self-test requirements (per roadmap Phase 16)
SELF_TESTS = [
    "future_leakage",
    "timestamp_causality",
    "execution_causality",
    "fees",
    "funding",
    "slippage",
    "latency",
]

# No synthetic fallback (per roadmap)
NO_SYNTHETIC_FALLBACK = True